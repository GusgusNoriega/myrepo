## businesses
*Engine:* InnoDB | *Collation:* utf8mb4_unicode_ci

### Columns
- id: bigint unsigned | null=NO | key=PRI | auto_increment
- owner_user_id: bigint unsigned | null=YES | key=MUL
- name: varchar(255) | null=NO
- slug: varchar(255) | null=NO | key=UNI
- domain: varchar(255) | null=YES | key=UNI
- subdomain: varchar(255) | null=YES | key=UNI
- country_code: varchar(2) | null=YES
- currency: varchar(3) | null=NO | default="USD"
- timezone: varchar(64) | null=YES
- locale: varchar(10) | null=YES
- contact_name: varchar(255) | null=YES
- contact_email: varchar(255) | null=YES
- settings: json | null=YES
- is_active: tinyint(1) | null=NO | default="1"
- created_at: timestamp | null=YES
- updated_at: timestamp | null=YES

### Indexes
- businesses_domain_unique: (domain) | unique
- businesses_owner_user_id_foreign: (owner_user_id) | non-unique
- businesses_slug_unique: (slug) | unique
- businesses_subdomain_unique: (subdomain) | unique
- PRIMARY: (id) | unique

### Foreign Keys
- businesses_owner_user_id_foreign: (owner_user_id)  users(id) | on update NO ACTION | on delete SET NULL

## categories
*Engine:* InnoDB | *Collation:* utf8mb4_unicode_ci

### Columns
- id: bigint unsigned | null=NO | key=PRI | auto_increment
- business_id: bigint unsigned | null=NO | key=MUL
- parent_id: bigint unsigned | null=YES | key=MUL
- name: varchar(255) | null=NO
- slug: varchar(255) | null=NO
- position: int unsigned | null=NO | default="0"
- created_at: timestamp | null=YES
- updated_at: timestamp | null=YES

### Indexes
- categories_business_id_index: (business_id) | non-unique
- categories_business_id_slug_unique: (business_id, slug) | unique
- categories_parent_id_foreign: (parent_id) | non-unique
- PRIMARY: (id) | unique

### Foreign Keys
- categories_business_id_foreign: (business_id)  businesses(id) | on update NO ACTION | on delete CASCADE
- categories_parent_id_foreign: (parent_id)  categories(id) | on update NO ACTION | on delete SET NULL

## documentos
*Engine:* InnoDB | *Collation:* utf8mb4_unicode_ci

### Columns
- id: bigint unsigned | null=NO | key=PRI | auto_increment
- business_id: bigint unsigned | null=NO | key=MUL
- owner_user_id: bigint unsigned | null=YES | key=MUL
- titulo: varchar(255) | null=NO
- descripcion: text | null=YES
- tipo: varchar(10) | null=NO | default="otro"
- ruta: varchar(255) | null=YES
- created_at: timestamp | null=YES
- updated_at: timestamp | null=YES

### Indexes
- documentos_business_id_tipo_index: (business_id, tipo) | non-unique
- documentos_owner_user_id_foreign: (owner_user_id) | non-unique
- PRIMARY: (id) | unique

### Foreign Keys
- documentos_business_id_foreign: (business_id)  businesses(id) | on update NO ACTION | on delete CASCADE
- documentos_owner_user_id_foreign: (owner_user_id)  users(id) | on update NO ACTION | on delete SET NULL

## failed_jobs
*Engine:* InnoDB | *Collation:* utf8mb4_unicode_ci

### Columns
- id: bigint unsigned | null=NO | key=PRI | auto_increment
- uuid: varchar(255) | null=NO | key=UNI
- connection: text | null=NO
- queue: text | null=NO
- payload: longtext | null=NO
- exception: longtext | null=NO
- failed_at: timestamp | null=NO | default="CURRENT_TIMESTAMP" | DEFAULT_GENERATED

### Indexes
- failed_jobs_uuid_unique: (uuid) | unique
- PRIMARY: (id) | unique

## inventories
*Engine:* InnoDB | *Collation:* utf8mb4_unicode_ci

### Columns
- id: bigint unsigned | null=NO | key=PRI | auto_increment
- variant_id: bigint unsigned | null=NO | key=MUL
- quantity: int unsigned | null=NO | default="0"
- low_stock_threshold: int unsigned | null=YES
- created_at: timestamp | null=YES
- updated_at: timestamp | null=YES

### Indexes
- inventories_variant_id_index: (variant_id) | non-unique
- PRIMARY: (id) | unique

### Foreign Keys
- inventories_variant_id_foreign: (variant_id)  product_variants(id) | on update NO ACTION | on delete CASCADE

## inventory_movements
*Engine:* InnoDB | *Collation:* utf8mb4_unicode_ci

### Columns
- id: bigint unsigned | null=NO | key=PRI | auto_increment
- variant_id: bigint unsigned | null=NO | key=MUL
- business_id: bigint unsigned | null=NO | key=MUL
- type: enum('in','out','adjust') | null=NO | key=MUL
- quantity: int | null=NO
- reason: varchar(255) | null=YES
- meta: json | null=YES
- created_at: timestamp | null=YES
- updated_at: timestamp | null=YES

### Indexes
- inventory_movements_business_id_variant_id_type_index: (business_id, variant_id, type) | non-unique
- inventory_movements_type_index: (type) | non-unique
- inventory_movements_variant_id_foreign: (variant_id) | non-unique
- PRIMARY: (id) | unique

### Foreign Keys
- inventory_movements_business_id_foreign: (business_id)  businesses(id) | on update NO ACTION | on delete CASCADE
- inventory_movements_variant_id_foreign: (variant_id)  product_variants(id) | on update NO ACTION | on delete CASCADE

## media
*Engine:* InnoDB | *Collation:* utf8mb4_unicode_ci

### Columns
- id: bigint unsigned | null=NO | key=PRI | auto_increment
- business_id: bigint unsigned | null=YES | key=MUL
- owner_user_id: bigint unsigned | null=YES | key=MUL
- is_public: tinyint(1) | null=NO | default="0"
- purpose: varchar(64) | null=YES
- model_type: varchar(255) | null=NO | key=MUL
- model_id: bigint unsigned | null=NO
- uuid: char(36) | null=YES | key=UNI
- collection_name: varchar(255) | null=NO
- name: varchar(255) | null=NO
- file_name: varchar(255) | null=NO
- mime_type: varchar(255) | null=YES
- disk: varchar(255) | null=NO
- conversions_disk: varchar(255) | null=YES
- size: bigint unsigned | null=NO
- manipulations: json | null=NO
- custom_properties: json | null=NO
- generated_conversions: json | null=NO
- responsive_images: json | null=NO
- order_column: int unsigned | null=YES | key=MUL
- created_at: timestamp | null=YES
- updated_at: timestamp | null=YES

### Indexes
- media_business_id_collection_name_index: (business_id, collection_name) | non-unique
- media_business_id_is_public_index: (business_id, is_public) | non-unique
- media_model_type_model_id_index: (model_type, model_id) | non-unique
- media_order_column_index: (order_column) | non-unique
- media_owner_user_id_foreign: (owner_user_id) | non-unique
- media_uuid_unique: (uuid) | unique
- PRIMARY: (id) | unique

### Foreign Keys
- media_business_id_foreign: (business_id)  businesses(id) | on update NO ACTION | on delete CASCADE
- media_owner_user_id_foreign: (owner_user_id)  users(id) | on update NO ACTION | on delete SET NULL

## memberships
*Engine:* InnoDB | *Collation:* utf8mb4_unicode_ci

### Columns
- id: bigint unsigned | null=NO | key=PRI | auto_increment
- user_id: bigint unsigned | null=NO | key=MUL
- business_id: bigint unsigned | null=NO | key=MUL
- role: enum('owner','admin','editor','viewer') | null=NO | default="viewer"
- state: enum('invited','active','suspended') | null=NO | default="active"
- accepted_at: timestamp | null=YES
- invited_by: bigint unsigned | null=YES | key=MUL
- created_at: timestamp | null=YES
- updated_at: timestamp | null=YES

### Indexes
- memberships_business_id_role_index: (business_id, role) | non-unique
- memberships_business_id_state_index: (business_id, state) | non-unique
- memberships_invited_by_foreign: (invited_by) | non-unique
- memberships_user_id_business_id_unique: (user_id, business_id) | unique
- PRIMARY: (id) | unique

### Foreign Keys
- memberships_business_id_foreign: (business_id)  businesses(id) | on update NO ACTION | on delete CASCADE
- memberships_invited_by_foreign: (invited_by)  users(id) | on update NO ACTION | on delete SET NULL
- memberships_user_id_foreign: (user_id)  users(id) | on update NO ACTION | on delete CASCADE

## migrations
*Engine:* InnoDB | *Collation:* utf8mb4_unicode_ci

### Columns
- id: int unsigned | null=NO | key=PRI | auto_increment
- migration: varchar(255) | null=NO
- batch: int | null=NO

### Indexes
- PRIMARY: (id) | unique

## model_has_permissions
*Engine:* InnoDB | *Collation:* utf8mb4_unicode_ci

### Columns
- permission_id: bigint unsigned | null=NO | key=PRI
- model_type: varchar(255) | null=NO | key=PRI
- model_id: bigint unsigned | null=NO | key=PRI

### Indexes
- model_has_permissions_model_id_model_type_index: (model_id, model_type) | non-unique
- PRIMARY: (permission_id, model_id, model_type) | unique

### Foreign Keys
- model_has_permissions_permission_id_foreign: (permission_id)  permissions(id) | on update NO ACTION | on delete CASCADE

## model_has_roles
*Engine:* InnoDB | *Collation:* utf8mb4_unicode_ci

### Columns
- role_id: bigint unsigned | null=NO | key=PRI
- model_type: varchar(255) | null=NO | key=PRI
- model_id: bigint unsigned | null=NO | key=PRI

### Indexes
- model_has_roles_model_id_model_type_index: (model_id, model_type) | non-unique
- PRIMARY: (role_id, model_id, model_type) | unique

### Foreign Keys
- model_has_roles_role_id_foreign: (role_id)  roles(id) | on update NO ACTION | on delete CASCADE

## oauth_access_tokens
*Engine:* InnoDB | *Collation:* utf8mb4_unicode_ci

### Columns
- id: varchar(100) | null=NO | key=PRI
- user_id: bigint unsigned | null=YES | key=MUL
- client_id: bigint unsigned | null=NO
- name: varchar(255) | null=YES
- scopes: text | null=YES
- revoked: tinyint(1) | null=NO
- created_at: timestamp | null=YES
- updated_at: timestamp | null=YES
- expires_at: datetime | null=YES

### Indexes
- oauth_access_tokens_user_id_index: (user_id) | non-unique
- PRIMARY: (id) | unique

## oauth_auth_codes
*Engine:* InnoDB | *Collation:* utf8mb4_unicode_ci

### Columns
- id: varchar(100) | null=NO | key=PRI
- user_id: bigint unsigned | null=NO | key=MUL
- client_id: bigint unsigned | null=NO
- scopes: text | null=YES
- revoked: tinyint(1) | null=NO
- expires_at: datetime | null=YES

### Indexes
- oauth_auth_codes_user_id_index: (user_id) | non-unique
- PRIMARY: (id) | unique

## oauth_clients
*Engine:* InnoDB | *Collation:* utf8mb4_unicode_ci

### Columns
- id: bigint unsigned | null=NO | key=PRI | auto_increment
- user_id: bigint unsigned | null=YES | key=MUL
- name: varchar(255) | null=NO
- secret: varchar(100) | null=YES
- provider: varchar(255) | null=YES
- redirect: text | null=NO
- personal_access_client: tinyint(1) | null=NO
- password_client: tinyint(1) | null=NO
- revoked: tinyint(1) | null=NO
- created_at: timestamp | null=YES
- updated_at: timestamp | null=YES

### Indexes
- oauth_clients_user_id_index: (user_id) | non-unique
- PRIMARY: (id) | unique

## oauth_personal_access_clients
*Engine:* InnoDB | *Collation:* utf8mb4_unicode_ci

### Columns
- id: bigint unsigned | null=NO | key=PRI | auto_increment
- client_id: bigint unsigned | null=NO
- created_at: timestamp | null=YES
- updated_at: timestamp | null=YES

### Indexes
- PRIMARY: (id) | unique

## oauth_refresh_tokens
*Engine:* InnoDB | *Collation:* utf8mb4_unicode_ci

### Columns
- id: varchar(100) | null=NO | key=PRI
- access_token_id: varchar(100) | null=NO | key=MUL
- revoked: tinyint(1) | null=NO
- expires_at: datetime | null=YES

### Indexes
- oauth_refresh_tokens_access_token_id_index: (access_token_id) | non-unique
- PRIMARY: (id) | unique

## password_reset_tokens
*Engine:* InnoDB | *Collation:* utf8mb4_unicode_ci

### Columns
- email: varchar(255) | null=NO | key=PRI
- token: varchar(255) | null=NO
- created_at: timestamp | null=YES

### Indexes
- PRIMARY: (email) | unique

## permissions
*Engine:* InnoDB | *Collation:* utf8mb4_unicode_ci

### Columns
- id: bigint unsigned | null=NO | key=PRI | auto_increment
- name: varchar(255) | null=NO | key=MUL
- guard_name: varchar(255) | null=NO
- created_at: timestamp | null=YES
- updated_at: timestamp | null=YES

### Indexes
- permissions_name_guard_name_unique: (name, guard_name) | unique
- PRIMARY: (id) | unique

## personal_access_tokens
*Engine:* InnoDB | *Collation:* utf8mb4_unicode_ci

### Columns
- id: bigint unsigned | null=NO | key=PRI | auto_increment
- tokenable_type: varchar(255) | null=NO | key=MUL
- tokenable_id: bigint unsigned | null=NO
- name: varchar(255) | null=NO
- token: varchar(64) | null=NO | key=UNI
- abilities: text | null=YES
- last_used_at: timestamp | null=YES
- expires_at: timestamp | null=YES
- created_at: timestamp | null=YES
- updated_at: timestamp | null=YES

### Indexes
- personal_access_tokens_token_unique: (token) | unique
- personal_access_tokens_tokenable_type_tokenable_id_index: (tokenable_type, tokenable_id) | non-unique
- PRIMARY: (id) | unique

## plan_features
*Engine:* InnoDB | *Collation:* utf8mb4_unicode_ci

### Columns
- id: bigint unsigned | null=NO | key=PRI | auto_increment
- plan_id: bigint unsigned | null=NO | key=MUL
- product_limit: int unsigned | null=NO
- storage_limit_bytes: bigint unsigned | null=NO
- staff_limit: int unsigned | null=NO
- asset_limit: int unsigned | null=YES
- category_limit: int unsigned | null=YES
- other: json | null=YES
- created_at: timestamp | null=YES
- updated_at: timestamp | null=YES

### Indexes
- plan_features_plan_id_foreign: (plan_id) | non-unique
- PRIMARY: (id) | unique

### Foreign Keys
- plan_features_plan_id_foreign: (plan_id)  plans(id) | on update NO ACTION | on delete CASCADE

## plans
*Engine:* InnoDB | *Collation:* utf8mb4_unicode_ci

### Columns
- id: bigint unsigned | null=NO | key=PRI | auto_increment
- code: varchar(255) | null=NO | key=UNI
- name: varchar(255) | null=NO
- price_usd: decimal(10,2) | null=NO | default="0.00"
- billing_interval: enum('month','year') | null=NO | default="month"
- is_active: tinyint(1) | null=NO | default="1"
- created_at: timestamp | null=YES
- updated_at: timestamp | null=YES

### Indexes
- plans_code_unique: (code) | unique
- PRIMARY: (id) | unique

## product_category
*Engine:* InnoDB | *Collation:* utf8mb4_unicode_ci

### Columns
- product_id: bigint unsigned | null=NO | key=PRI
- category_id: bigint unsigned | null=NO | key=PRI

### Indexes
- PRIMARY: (product_id, category_id) | unique
- product_category_category_id_index: (category_id) | non-unique

### Foreign Keys
- product_category_category_id_foreign: (category_id)  categories(id) | on update NO ACTION | on delete CASCADE
- product_category_product_id_foreign: (product_id)  products(id) | on update NO ACTION | on delete CASCADE

## product_variants
*Engine:* InnoDB | *Collation:* utf8mb4_unicode_ci

### Columns
- id: bigint unsigned | null=NO | key=PRI | auto_increment
- product_id: bigint unsigned | null=NO | key=MUL
- sku: varchar(255) | null=NO
- barcode: varchar(64) | null=YES
- name: varchar(255) | null=YES
- price_cents: int unsigned | null=YES
- attributes: json | null=YES
- created_at: timestamp | null=YES
- updated_at: timestamp | null=YES

### Indexes
- PRIMARY: (id) | unique
- product_variants_product_id_barcode_index: (product_id, barcode) | non-unique
- product_variants_product_id_index: (product_id) | non-unique
- product_variants_product_id_sku_unique: (product_id, sku) | unique

### Foreign Keys
- product_variants_product_id_foreign: (product_id)  products(id) | on update NO ACTION | on delete CASCADE

## products
*Engine:* InnoDB | *Collation:* utf8mb4_unicode_ci

### Columns
- id: bigint unsigned | null=NO | key=PRI | auto_increment
- business_id: bigint unsigned | null=NO | key=MUL
- category_id: bigint unsigned | null=YES | key=MUL
- name: varchar(255) | null=NO
- slug: varchar(255) | null=NO
- sku: varchar(255) | null=NO
- barcode: varchar(64) | null=YES
- description: text | null=YES
- status: enum('draft','active','archived') | null=NO | default="draft"
- has_variants: tinyint(1) | null=NO | default="0"
- price_cents: int unsigned | null=YES
- cost_cents: int unsigned | null=YES
- compare_at_price_cents: int unsigned | null=YES
- currency: varchar(3) | null=NO | default="USD"
- tax_included: tinyint(1) | null=NO | default="1"
- attributes: json | null=YES
- weight_grams: int unsigned | null=YES
- dimensions: json | null=YES
- created_at: timestamp | null=YES
- updated_at: timestamp | null=YES
- deleted_at: timestamp | null=YES
- published_at: timestamp | null=YES

### Indexes
- PRIMARY: (id) | unique
- products_business_id_barcode_index: (business_id, barcode) | non-unique
- products_business_id_category_id_status_index: (business_id, category_id, status) | non-unique
- products_business_id_index: (business_id) | non-unique
- products_business_id_price_cents_index: (business_id, price_cents) | non-unique
- products_business_id_sku_unique: (business_id, sku) | unique
- products_business_id_slug_unique: (business_id, slug) | unique
- products_business_id_status_index: (business_id, status) | non-unique
- products_category_id_foreign: (category_id) | non-unique

### Foreign Keys
- products_business_id_foreign: (business_id)  businesses(id) | on update NO ACTION | on delete CASCADE
- products_category_id_foreign: (category_id)  categories(id) | on update NO ACTION | on delete SET NULL

## role_has_permissions
*Engine:* InnoDB | *Collation:* utf8mb4_unicode_ci

### Columns
- permission_id: bigint unsigned | null=NO | key=PRI
- role_id: bigint unsigned | null=NO | key=PRI

### Indexes
- PRIMARY: (permission_id, role_id) | unique
- role_has_permissions_role_id_foreign: (role_id) | non-unique

### Foreign Keys
- role_has_permissions_permission_id_foreign: (permission_id)  permissions(id) | on update NO ACTION | on delete CASCADE
- role_has_permissions_role_id_foreign: (role_id)  roles(id) | on update NO ACTION | on delete CASCADE

## roles
*Engine:* InnoDB | *Collation:* utf8mb4_unicode_ci

### Columns
- id: bigint unsigned | null=NO | key=PRI | auto_increment
- name: varchar(255) | null=NO | key=MUL
- guard_name: varchar(255) | null=NO
- created_at: timestamp | null=YES
- updated_at: timestamp | null=YES

### Indexes
- PRIMARY: (id) | unique
- roles_name_guard_name_unique: (name, guard_name) | unique

## subscriptions
*Engine:* InnoDB | *Collation:* utf8mb4_unicode_ci

### Columns
- id: bigint unsigned | null=NO | key=PRI | auto_increment
- business_id: bigint unsigned | null=NO | key=MUL
- plan_id: bigint unsigned | null=NO | key=MUL
- status: enum('trialing','active','past_due','canceled') | null=NO | key=MUL
- current_period_start: timestamp | null=NO
- current_period_end: timestamp | null=NO
- trial_ends_at: timestamp | null=YES
- canceled_at: timestamp | null=YES
- cancel_at_period_end: tinyint(1) | null=NO | default="0"
- external_ref: varchar(255) | null=YES
- external_customer_id: varchar(255) | null=YES
- payment_method: json | null=YES
- created_at: timestamp | null=YES
- updated_at: timestamp | null=YES

### Indexes
- PRIMARY: (id) | unique
- subscriptions_business_id_status_index: (business_id, status) | non-unique
- subscriptions_plan_id_foreign: (plan_id) | non-unique
- subscriptions_status_index: (status) | non-unique

### Foreign Keys
- subscriptions_business_id_foreign: (business_id)  businesses(id) | on update NO ACTION | on delete CASCADE
- subscriptions_plan_id_foreign: (plan_id)  plans(id) | on update NO ACTION | on delete RESTRICT

## usage_counters
*Engine:* InnoDB | *Collation:* utf8mb4_unicode_ci

### Columns
- business_id: bigint unsigned | null=NO | key=PRI
- products_count: int unsigned | null=NO | default="0"
- assets_count: int unsigned | null=NO | default="0"
- storage_bytes: bigint unsigned | null=NO | default="0"
- created_at: timestamp | null=YES
- updated_at: timestamp | null=YES

### Indexes
- PRIMARY: (business_id) | unique

### Foreign Keys
- usage_counters_business_id_foreign: (business_id)  businesses(id) | on update NO ACTION | on delete CASCADE

## users
*Engine:* InnoDB | *Collation:* utf8mb4_unicode_ci

### Columns
- id: bigint unsigned | null=NO | key=PRI | auto_increment
- name: varchar(255) | null=NO
- email: varchar(255) | null=NO | key=UNI
- email_verified_at: timestamp | null=YES
- password: varchar(255) | null=NO
- remember_token: varchar(100) | null=YES
- active_business_id: bigint unsigned | null=YES | key=MUL
- created_at: timestamp | null=YES
- updated_at: timestamp | null=YES

### Indexes
- PRIMARY: (id) | unique
- users_active_business_id_index: (active_business_id) | non-unique
- users_email_unique: (email) | unique

### Foreign Keys
- users_active_business_id_foreign: (active_business_id)  businesses(id) | on update NO ACTION | on delete SET NULL