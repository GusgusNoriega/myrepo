

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="layout">
    
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-brand">
            <h2>Mi Sistema</h2>
        </div>

        <nav class="menu">
            <ul>
                
                <li class="menu-item">
                    <button class="accordion" data-section="sec1">Sección 1</button>
                    <ul class="submenu">
                        <li>
                            <a  href="<?php echo e(route('seccion11')); ?>"
                                class="<?php echo e(request()->routeIs('seccion11') ? 'active' : ''); ?>"
                            >Opción 1-1</a></li>
                        <li>
                            <a  href="<?php echo e(route('seccion12')); ?>"
                                class="<?php echo e(request()->routeIs('seccion12') ? 'active' : ''); ?>"
                            >Opción 1-2</a></li>
                    </ul>
                </li>

                
                <li class="menu-item">
                    <button class="accordion" data-section="sec2">Sección 2</button>
                    <ul class="submenu">
                        <li>
                            <a  href="<?php echo e(route('seccion21')); ?>"
                                class="<?php echo e(request()->routeIs('seccion21') ? 'active' : ''); ?>"
                            >Opción 2-1</a></li>
                        <li>
                            <a  href="<?php echo e(route('seccion22')); ?>"
                                class="<?php echo e(request()->routeIs('seccion22') ? 'active' : ''); ?>"
                            >Opción 2-2</a></li>
                    </ul>
                </li>
            </ul>
        </nav>
    </aside>

    
    <main class="main">
        <header class="main-header">
            <button id="sidebarToggle" class="hamburger" aria-label="Mostrar/ocultar menú">
                &#9776;
            </button>
            <h1><?php echo $__env->yieldContent('title'); ?></h1>
        </header>

        <section class="content">
            <p>Contenido principal…</p>
        </section>

        <footer class="main-footer">
            <small>© 2025 Mi Sistema</small>
        </footer>
    </main>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\myrepo\resources\views/dashboard.blade.php ENDPATH**/ ?>