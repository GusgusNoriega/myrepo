

<?php $__env->startSection('title', 'Panel — MyRepo'); ?>
<?php $__env->startSection('page_title', 'Dashboard'); ?>




<?php $__env->startSection('content'); ?>
     <h2>Vista: Opción 1-2</h2>
    
<input type="hidden" name="featured_image_id" id="featured_image_id"
       value=""
       data-mm="image"            
       data-mm-multiple="false"   
       data-mm-preview="#selector"
       data-mm-title="Selecciona imagen de portada">


<div id="selector" class="mt-2"></div>

<input type="hidden" name="gallery_ids" id="gallery_ids"
       value=""
       data-mm="image"
       data-mm-multiple="true"
       data-mm-title="Selecciona imágenes de la galería">


<input type="hidden" name="brochure_id" id="brochure_id"
       value=""
       data-mm="document"
       data-mm-multiple="false"
       data-mm-title="Selecciona el brochure">


<input type="hidden" name="attachments_ids" id="attachments_ids"
       value=""
       data-mm="document"
       data-mm-multiple="true"
       data-mm-title="Selecciona adjuntos">

    <?php if (isset($component)) { $__componentOriginala408478ef62be7bd79d3249658f662cd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala408478ef62be7bd79d3249658f662cd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.media-manager','data' => ['apiBase' => url('http://myrepo.test/api/media')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('media-manager'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['api-base' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(url('http://myrepo.test/api/media'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala408478ef62be7bd79d3249658f662cd)): ?>
<?php $attributes = $__attributesOriginala408478ef62be7bd79d3249658f662cd; ?>
<?php unset($__attributesOriginala408478ef62be7bd79d3249658f662cd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala408478ef62be7bd79d3249658f662cd)): ?>
<?php $component = $__componentOriginala408478ef62be7bd79d3249658f662cd; ?>
<?php unset($__componentOriginala408478ef62be7bd79d3249658f662cd); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\myrepo\resources\views/secciones/seccion12.blade.php ENDPATH**/ ?>