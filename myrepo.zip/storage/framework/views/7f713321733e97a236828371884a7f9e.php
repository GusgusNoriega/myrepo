

<?php $__env->startSection('title', 'Seccion 2-2'); ?>

<?php $__env->startSection('content'); ?>
    <h2>Vista: Opción 2-2</h2>
    <p>Aquí va el contenido específico de esta página (tablas, formularios, etc.).</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\myrepo\resources\views/secciones/seccion22.blade.php ENDPATH**/ ?>