<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <title>@yield('title', 'Mi Proyecto')</title>

    <!-- Hoja de estilos nativa -->
    <link rel="stylesheet" href="{{ asset('assets/css/style.css') }}">
</head>
<body>
    <p>hola este es mi proyecto</p>

    <!-- Script opcional -->
    <script src="{{ asset('assets/js/main.js') }}"></script>
</body>
</html>
