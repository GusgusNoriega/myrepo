<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />

  <title><?php echo $__env->yieldContent('title', 'Tu Tienda Online — Plataforma para crear tu e-commerce'); ?></title>
  <meta name="description" content="<?php echo $__env->yieldContent('meta_description', 'Crea tu propia tienda en línea con pagos, gestión de productos y envíos en un solo lugar.'); ?>">

  
  <script src="https://cdn.tailwindcss.com"></script>
  <script>
    // Colores de marca (puedes ajustar)
    tailwind.config = {
      theme: {
        extend: {
          colors: {
            brand: {
              50:'#f0faff',100:'#e0f2fe',200:'#bae6fd',300:'#7dd3fc',400:'#38bdf8',
              500:'#0ea5e9',600:'#0284c7',700:'#0369a1',800:'#075985',900:'#0c4a6e'
            }
          }
        }
      }
    }
  </script>

  
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700;800&display=swap" rel="stylesheet">
  <style>
    html, body { font-family: 'Inter', system-ui, -apple-system, Segoe UI, Roboto, Ubuntu, Cantarell, Noto Sans, Helvetica, Arial, 'Apple Color Emoji', 'Segoe UI Emoji'; }
  </style>

  <?php echo $__env->yieldPushContent('styles'); ?>
  <?php echo $__env->yieldContent('head'); ?> 
</head>
<body class="bg-white text-slate-800">

  
  <?php if (isset($component)) { $__componentOriginal3c0808d0ccb9dfd11d29783234199f91 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3c0808d0ccb9dfd11d29783234199f91 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.web.header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('web.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3c0808d0ccb9dfd11d29783234199f91)): ?>
<?php $attributes = $__attributesOriginal3c0808d0ccb9dfd11d29783234199f91; ?>
<?php unset($__attributesOriginal3c0808d0ccb9dfd11d29783234199f91); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3c0808d0ccb9dfd11d29783234199f91)): ?>
<?php $component = $__componentOriginal3c0808d0ccb9dfd11d29783234199f91; ?>
<?php unset($__componentOriginal3c0808d0ccb9dfd11d29783234199f91); ?>
<?php endif; ?>

  <main>
    <?php echo $__env->yieldContent('content'); ?>
  </main>

  
  <?php if (isset($component)) { $__componentOriginal20d90b51c541c707c0abda6b84690e20 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal20d90b51c541c707c0abda6b84690e20 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.web.footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('web.footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal20d90b51c541c707c0abda6b84690e20)): ?>
<?php $attributes = $__attributesOriginal20d90b51c541c707c0abda6b84690e20; ?>
<?php unset($__attributesOriginal20d90b51c541c707c0abda6b84690e20); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal20d90b51c541c707c0abda6b84690e20)): ?>
<?php $component = $__componentOriginal20d90b51c541c707c0abda6b84690e20; ?>
<?php unset($__componentOriginal20d90b51c541c707c0abda6b84690e20); ?>
<?php endif; ?>

  <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\laragon\www\myrepo\resources\views/layouts/web.blade.php ENDPATH**/ ?>