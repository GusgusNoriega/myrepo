@extends('layouts.admin')

@section('title', 'Seccion 2-2')

@section('content')
    <h2>Vista: Opción 2-2</h2>
    <p>Aquí va el contenido específico de esta página (tablas, formularios, etc.).</p>
@endsection