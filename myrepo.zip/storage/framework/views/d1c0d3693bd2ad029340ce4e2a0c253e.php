<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <?php if(auth()->guard()->check()): ?>
        <?php if(session('api_token')): ?>
            <meta name="api-token" content="<?php echo e(session('api_token')); ?>">
        <?php endif; ?>
    <?php endif; ?>
    <title><?php echo $__env->yieldContent('title', 'Panel'); ?> – Mi Sistema</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/style.css', 'resources/js/main.js']); ?>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body>
<div class="layout">
    <!-- Barra lateral -->
    <?php echo $__env->make('partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Contenedor principal -->
    <main class="main">
        <header class="main-header">
            <button id="sidebarToggle" class="hamburger" aria-label="Mostrar/ocultar menú">
                &#9776;
            </button>
            <h1><?php echo $__env->yieldContent('title', 'Panel'); ?></h1>
            <form id="logout-form" method="POST" action="<?php echo e(route('logout')); ?>" class="hidden">
                 <?php echo csrf_field(); ?>
            </form>

            <a href="#" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                Cerrar sesión hola
            </a>
        </header>

        <section class="content">
            <?php echo $__env->yieldContent('content'); ?>
        </section>

        <footer class="main-footer">
            <small>© 2025 Mi Sistema</small>
        </footer>
    </main>
</div>
</body>
</html>
<?php /**PATH C:\laragon\www\myrepo\resources\views/layouts/admin.blade.php ENDPATH**/ ?>