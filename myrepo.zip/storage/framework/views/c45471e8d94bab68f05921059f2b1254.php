<!doctype html>
<html lang="<?php echo e(str_replace('_','-',app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    
    <?php if(session('api_token')): ?>
        <meta name="api-token" content="<?php echo e(session('api_token')); ?>">
    <?php endif; ?>

    <title><?php echo e(config('app.name')); ?></title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/style.css']); ?>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body>
    <?php echo $__env->yieldContent('content'); ?>

    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/main.js']); ?>
</body>
</html>
<?php /**PATH C:\laragon\www\myrepo\resources\views/layouts/guest.blade.php ENDPATH**/ ?>