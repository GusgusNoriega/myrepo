@extends('layouts.admin')

@section('title', 'Seccion 2-1')

@section('content')
    <h2>Vista: Opción 2-1</h2>
    <p>Aquí va el contenido específico de esta página (tablas, formularios, etc.).</p>
@endsection